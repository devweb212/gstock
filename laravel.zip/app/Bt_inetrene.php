<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bt_inetrene extends Model
{
    //
	
	
}


