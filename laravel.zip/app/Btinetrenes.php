<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Btinetrenes extends Model
{
    //
}
