<div class="card {{ $class }}">
    <h5 class="card-header">{{ $title }}</h5>
    <div class="card-body">
       <p class="card-text">{{ $slot }}</p>
    </div>
</div>