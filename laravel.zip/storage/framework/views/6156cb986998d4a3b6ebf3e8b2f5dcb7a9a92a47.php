<?php $__env->startSection('content'); ?>
<div class="app-main__inner">
   <div class="app-page-title">
      <div class="page-title-wrapper">
         <div class="page-title-heading">
            <div class="page-title-icon">
               <i class="lnr-picture text-danger">
               </i>
            </div>
            <div>AJOUTER UNE SOUS FAMILLE
            </div>
         </div>
         <div class="page-title-actions">
            <div class="d-inline-block dropdown">
               <a href="/listefamille" class="btn-shadow dropdown-toggle btn btn-info">
               <span class="btn-icon-wrapper pr-2 opacity-7">
               </span>
               Listes des familles
               </a>
            </div>
         </div>
      </div>
   </div>
   <div class="main-card mb-3 card">
      <div class="card-body">
         <h5 class="card-title">Ajouter une sous Famille</h5>
         <form action="/addsfamille" method="post" class="needs-validation" novalidate>
            <?php echo csrf_field(); ?>
            <div class="form-row">
               <div class="col-md-12 mb-12">
                  <label for="validationCustom01">
                  Sous Famille
                  </label>
                  <input type="text" class="form-control" id="validationCustom01" placeholder="Nom de sous Famille" value=""  name="sousfamille" required>
                  <div class="valid-feedback">
                     Looks good!
                  </div>
             </div>
           
			<div class="col-md-4 mb-3" style="margin-top: 20px;">
				<label for="validationCustom044">  Selectionner une Famille</label>										
				<select  data-live-search="true"  name="id_famille" title="Please select fruit" data-live-search-placeholder="Recherche "  class="form-control selectpicker" >
				<option value="" selected>....</option>									   
				  <?php $__currentLoopData = $famille; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($item->id); ?>"><?php echo e($item->famille); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>                                    
			</div>
    </div>

		
            <button class="btn btn-primary" type="submit">AJOUTER UNE SOUS FAMILLE</button>
         </form>
         <script>
            // Example starter JavaScript for disabling form submissions if there are invalid fields
            (function() {
                'use strict';
                window.addEventListener('load', function() {
                    // Fetch all the forms we want to apply custom Bootstrap validation styles to
                    var forms = document.getElementsByClassName('needs-validation');
                    // Loop over them and prevent submission
                    var validation = Array.prototype.filter.call(forms, function(form) {
                        form.addEventListener('submit', function(event) {
                            if (form.checkValidity() === false) {
                                event.preventDefault();
                                event.stopPropagation();
                            }
                            form.classList.add('was-validated');
                        }, false);
                    });
                }, false);
            })();
         </script>
      </div>
      <div class="card-body">
         <h5 class="card-title">Accueil</h5>
         <div class="col-lg-12">
            <div class="main-card mb-3 card">
               <div class="card-body">
                  <h5 class="card-title">LISTE DES PIÈCES</h5>
                  <table class="mb-0 table table-hover" style="text-align:center">
                     <thead>
                        <tr>
						
						
                           <th>Date Ajouter</th>
                           <th>Sous Famille</th>
                           <th>Famille</th>
                           <th>Action</th>
                        </tr>
                     </thead>
                     <tbody>
					
                         <?php $__currentLoopData = $sous_famille; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
			<tr>		
						   <td><?php echo e($item->created_at->format('Y-m-d')); ?></td>
                           <td><?php echo e($item->sousfamille); ?></td>
                           <td><?php $__currentLoopData = $famille; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($item->id_famille==$itemf->id): ?> <?php echo e($itemf->famille); ?> <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                           <td><i class="fa fa-fw" aria-hidden="true" title="Copy to use edit"></i></td>   
			</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\laravel\resources\views/addsfamille.blade.php ENDPATH**/ ?>