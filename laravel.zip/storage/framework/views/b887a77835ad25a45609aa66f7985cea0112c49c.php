<?php $__env->startSection('content'); ?>
<div class="app-main__inner">
   <div class="app-page-title">
      <div class="page-title-wrapper">
         <div class="page-title-heading">
            <div class="page-title-icon">
               <i class="lnr-picture text-danger">
               </i>
            </div>
            <div>Stock Initial 2021
            </div>
         </div>
         <div class="page-title-actions">
          
         </div>
      </div>
   </div>
   <div class="main-card mb-3 card">
      <div class="card-body">
			 <div class="row">
	   <div class="col-md-6 mb-6">
         <h5 class="card-title">Accueil</h5>
		 </div>
		 <div class="col-md-6 mb-6" style="text-align: right;padding-right: 28px;padding-bottom: 20px;">
       <a href="/inventaires_initial" class="btn-shadow dropdown-toggle btn btn-info">Stock Initial 2021</a>	
		<a href="/inventaires_final" class="btn-shadow dropdown-toggle btn btn-info">Stock Final 2020</a>
        </div>
					</div>	
         <div class="col-lg-12">
            <div class="main-card mb-3 card">
               <div class="card-body">
                  <h5 class="card-title">LISTE DES ARTICLES</h5>
                  <div class="form-row">
<form action="/inventaire_actuel" method="post" class="needs-validation" novalidate style="width: 100%;">
                        <?php echo csrf_field(); ?>
                        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
						    <div class="form-row">	
                       
					 <div class="col-md-3 mb-3">
                           <label for="validationCustom01" style="display: block;">
                           FILTRER PAR FAMILLE
                           </label>
              <select  id="famillefilter" name="famillefilter" data-placeholder="selectionner un article..." class="chosen-select sortie "  tabindex="-1" required>
						        <option value="0" selected="selected">...</option>
                              <?php $__currentLoopData = $famille; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($item->id); ?>"><?php echo e($item->famille); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </select>
                        </div>
					 <div class="col-md-3 mb-3">
                              <label for="validationCustom01" style="display: block;">
                              FILTRER PAR SOUS FAMILLE
                           </label>
                           <select  id="sfamillefilter" name="sfamillefilter" data-placeholder="selectionner un article..." class="chosen-select sfamille " tabindex="-1" required>
						        <option value="0" selected="selected">...</option>
                              <?php $__currentLoopData = $sous_famille; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($item->id); ?>"><?php echo e($item->sousfamille); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </select>
                        </div>
						 <div class="col-md-3 mb-3">                        
		<label for="validationCustom01" style="display: block;">FILTRER PAR ARTICLE </label>
       <select name="invslect"  class="chosen-select form-control " style="width: 100%;" id="invslect">
						  <option value="0" selected="selected">...</option>
							 <?php $__currentLoopData = $listeInvpieces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ajouterpieces): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($ajouterpieces->id); ?>"><?php echo e($ajouterpieces->name_piece); ?>- <?php echo e($ajouterpieces->ref); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </select>
                        </div>
<div class="col-md-3 mb-3" style=" text-align: right;padding-top: 28px;">
        <input type="submit" id="btn" value="Imprimer" class="btn-shadow dropdown-toggle btn btn-info"> 
                        </div>
						
						
						  
					
                      </div>
					</form>
                  </div>
           

<div id='DivIdToPrint'>
<table class="mb-0 table table-hover" style="text-align:center" border="1">
                        <thead>
                           <tr>
                              <th>Date Ajouter</th>
                              <th>Article</th>
                              <th>Quantité</th>
                              <th>Référence</th>
                              <th>Unite</th>
                              <th>Famille </th>
                              <th>Sous Famille </th>
                            
                           </tr>
                        </thead>
                        <tbody id="inventaire">
                           <?php $__currentLoopData = $listeInvpieces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listepiec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                              <th scope="row"><?php echo e($listepiec->created_at->format('Y-m-d')); ?></th>
                              <th scope="row">  <?php echo e($listepiec->name_piece); ?></th>
                              <td><?php echo e($listepiec->inventaire); ?></td>
                              <td><?php echo e($listepiec->ref); ?></td>
                              <td>
                                 <?php echo e($listepiec->unite); ?>

                              </td>
                              <td>
                                 <?php $__currentLoopData = $famille; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>			
                                 <?php if($item->id==$listepiec->id_famille ): ?>
                                 <?php echo e($item->famille); ?>

                                 <?php endif; ?>	 
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
                              </td>
                              <td><?php $__currentLoopData = $sous_famille; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>			
                                 <?php if($item->id==$listepiec->id_sfamille ): ?>
                                 <?php echo e($item->sousfamille); ?>

                                 <?php endif; ?>	 
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
                              </td>
                           
                           </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                   
				   </table>
  </div>           
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\laravel\resources\views/inventaires_initial.blade.php ENDPATH**/ ?>