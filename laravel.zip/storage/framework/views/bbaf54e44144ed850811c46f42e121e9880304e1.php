
                           <?php $__currentLoopData = $listeInvpieces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listepiec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                              <th scope="row"><?php echo e($listepiec->created_at->format('Y-m-d')); ?></th>
                              <th scope="row">  <?php echo e($listepiec->name_piece); ?></th>
                              <td><?php echo e($listepiec->inventaire); ?></td>
                              <td><?php echo e($listepiec->ref); ?></td>
                              <td>
                                 <?php echo e($listepiec->unite); ?>

                              </td>
                              <td>
                                 <?php $__currentLoopData = $famille; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>			
                                 <?php if($item->id==$listepiec->id_famille ): ?>
                                 <?php echo e($item->famille); ?>

                                 <?php endif; ?>	 
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
                              </td>
                              <td><?php $__currentLoopData = $sous_famille; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>			
                                 <?php if($item->id==$listepiec->id_sfamille ): ?>
                                 <?php echo e($item->sousfamille); ?>

                                 <?php endif; ?>	 
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
                              </td>
                              <td>
                                 		
                              </td>
                           </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                   <?php /**PATH D:\xamp\htdocs\laravel\resources\views/ajaxinventaire.blade.php ENDPATH**/ ?>