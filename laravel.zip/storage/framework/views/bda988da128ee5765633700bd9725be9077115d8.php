<?php $__env->startSection('content'); ?>
<div class="app-main__inner">
   <div class="app-page-title">
      <div class="page-title-wrapper">
         <div class="page-title-heading">
            <div class="page-title-icon">
               <i class="lnr-picture text-danger">
               </i>
            </div>
            <div>Les Entrées
            </div>
         </div>
         <div class="page-title-actions">
            <div class="d-inline-block dropdown">
               <a href="/piece/create" class="btn-shadow dropdown-toggle btn btn-info">
               <span class="btn-icon-wrapper pr-2 opacity-7">
               <i class="fa fa-plus fa-w-20"></i>
               </span>
               AJOUTER UN ENTRÉE
               </a>
            </div>
         </div>
      </div>
   </div>
   <div class="main-card mb-3 card">
      <div class="card-body">
         <h5 class="card-title">Accueil</h5>
         <div class="col-lg-12">
            <div class="main-card mb-3 card">
               <div class="card-body">
                  <h5 class="card-title">LISTE DES PIÈCES</h5>
                  <table class="mb-0 table table-hover" style="text-align:center">
                     <thead>
                        <tr>
                           <th>Date BL</th>
                           <th>N° BL</th>
                           <th>Désignation</th>
                           <th>Quantité</th>
                           <th>Référence</th>
                           <th>Unite</th>
                           <th>Fournisseur</th>
                           <th>Equivalent</th>
                           <th>Observation</th>
                  
                           <th style="min-width: 100px;">Action</th>
                        </tr>
                     </thead>
                     <tbody>
                     <tbody>
                        <?php $__currentLoopData = $ajoutersortiesall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listepiec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                           <th scope="row"><?php echo e($listepiec->updated_at); ?></th>
                           <th scope="row"><?php echo e($listepiec->bl); ?></th>
                           <th scope="row">  <?php echo e($listepiec->name_piece); ?></th>
                           <td><?php echo e($listepiec->quantite); ?></td>
                           <td><?php echo e($listepiec->ref); ?></td>
                           <td>
                              <?php if($listepiec->unite==1): ?>
                              Unite 
                              <?php endif; ?>
                              <?php if($listepiec->unite==2): ?>
                              Centimètre
                              <?php endif; ?>
                              <?php if($listepiec->unite==3): ?>
                              Litre 
                              <?php endif; ?>
                              <?php if($listepiec->unite==4): ?>
                              Gramme
                              <?php endif; ?>
                           </td>
                           <td><?php echo e($listepiec->forn); ?></td>
                           <td><?php echo e($listepiec->equiv); ?></td>
                           <td><?php echo e($listepiec->obser); ?></td>
    
                           <td>
                              <i class="fa fa-fw" aria-hidden="true" title="Copy to use edit"></i>                                                                                            			
                                                                                     
                           </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\laravel\resources\views/home.blade.php ENDPATH**/ ?>