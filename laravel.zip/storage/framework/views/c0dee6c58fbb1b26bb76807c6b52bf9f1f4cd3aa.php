<?php $__env->startSection('content'); ?>
<div class="app-main__inner">
   <div class="app-page-title">
      <div class="page-title-wrapper">
         <div class="page-title-heading">
            <div class="page-title-icon">
               <i class="lnr-picture text-danger">
               </i>
            </div>
            <div>
            </div>
         </div>
         <div class="page-title-actions">
            <div class="d-inline-block dropdown">
               <a href="/addsousfamille" class="btn-shadow dropdown-toggle btn btn-info">
               <span class="btn-icon-wrapper pr-2 opacity-7">
               </span>
              AJOUTER UNE SOUS FAMILLE
               </a>
            </div>
         </div>
      </div>
   </div>
   <div class="main-card mb-3 card">
      
      <div class="card-body">
         <h5 class="card-title">Accueil</h5>
         <div class="col-lg-12">
            <div class="main-card mb-3 card">
               <div class="card-body">
                  <h5 class="card-title">LISTE DES PIÈCES</h5>
                  <table class="mb-0 table table-hover" style="text-align:center">
                     <thead>
                        <tr>
						
						
                           <th>Date Ajouter</th>
                           <th>Sous Famille</th>
                           <th>Famille</th>
                           <th>Action</th>
                        </tr>
                     </thead>
                     <tbody>
					
                         <?php $__currentLoopData = $sous_famille; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
			<tr>		
						   <td><?php echo e($item->created_at->format('Y-m-d')); ?></td>
                           <td><?php echo e($item->sousfamille); ?></td>
                           <td><?php $__currentLoopData = $famille; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($item->id_famille==$itemf->id): ?> <?php echo e($itemf->famille); ?> <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                           <td><i class="fa fa-fw" aria-hidden="true" title="Copy to use edit"></i></td>   
			</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\laravel\resources\views/listefamille.blade.php ENDPATH**/ ?>